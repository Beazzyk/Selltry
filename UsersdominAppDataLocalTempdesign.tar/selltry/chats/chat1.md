# Selltry Landing & Prototyp

_Started 2026-05-12 21:28 UTC_

---

## User

<system-info comment="Only acknowledge these if relevant">
Project title is now "Selltry"
Current date is now May 12, 2026
</system-info>

<default aesthetic>
If no references, art direction or design systems were provided, use this default professional modern, minimal aesthetic as a base. Declare your choice out loud so you stick to it. Guidance:
- Choose a type pairing from web-safe set or Google Fonts. Helvetica is a good choice. Avoid hard-to-read or overly stylized fonts. Use 1-3 fonts only.
- Foreground and background: choose a color tone (warm, cool, neutral, something in-between). Use subtly-toned whites and blacks; avoid saturations above 0.02 for whites.
- Accents: choose 0-2 additional accent colors using oklch. All accents should share same chroma and lightness; vary hue.
- NEVER write out an SVG yourself that's more complicated than a square, circle, diamond, etc.
- For imagery, never hand-draw SVGs; use subtly-striped SVG placeholders instead with monospace explainers for what should be dropped there (e.g. “product shot”)

CRITICAL: ignore default aesthetic entirely if given other aesthetic instructions like reference images, design systems or guidance, or if there are files in the project already.
</default aesthetic>

<pasted_text name="Pasted text (158 lines)">
 Zaprojektuj landing page i system UI dla SaaS o nazwie „Selltry"
  (lub AutoLister — do ustalenia przez właściciela).

  ─────────────────────────────────────────────
  CZYM JEST PRODUKT
  ─────────────────────────────────────────────
  Multichannel marketplace SaaS dla polskich sprzedawców.
  Pozwala wystawiać ogłoszenia na Allegro, OLX, Otomoto i Ovoko
  z jednego panelu. Narzędzie do zarządzania sprzedażą online
  dla małych i średnich sprzedawców — od części samochodowych
  po elektronikę, odzież, narzędzia, sport i dom.

  ─────────────────────────────────────────────
  DOCELOWY UŻYTKOWNIK
  ─────────────────────────────────────────────
  Profil 1: Sprzedawca części samochodowych — warsztat lub
    osoba prywatna, sprzedaje 20-200 ogłoszeń/miesiąc,
    traci czas wystawiając ręcznie na każdej platformie osobno.

  Profil 2: Sprzedawca wielokategoriowy — elektronika, ubrania,
    narzędzia. Ma sklep lub sprzedaje z domu, chce automatyzacji.

  Ból: każda platforma to osobny panel, osobne zdjęcia, inna
    struktura tytułu, inny opis. Seltry robi to raz za wszystkich.

  ─────────────────────────────────────────────
  KLUCZOWE FUNKCJE DO ZAPREZENTOWANIA NA LANDING
  ─────────────────────────────────────────────
  1. JEDNO OGŁOSZENIE → WIELE PLATFORM
     Tworzysz raz, publikujesz na Allegro + OLX + Otomoto + Ovoko
     jednym kliknięciem. Każda platforma dostaje odpowiedni format.

  2. AI GENERATOR OPISÓW I TYTUŁÓW
     Wpisujesz markę i model → AI (Claude) generuje pełny opis
     marketingowy: specyfikację techniczną, wymiary, kompatybilność,
     cechy. Tytuły zoptymalizowane SEO osobno dla każdej platformy
     (Allegro max 75 znaków, OLX max 70 itd.)

  3. ZARZĄDZANIE KATEGORIAMI
     7 kategorii głównych: Motoryzacja, Elektronika, Dom i ogród,
     Moda, Sport, Narzędzia, Inne — każda z podkategoriami i listą
     marek (Samsung, Bosch, Nike, Makita...) do wyboru.

  4. MARŻE PER PLATFORMA
     Ustawiasz marżę % lub kwotową per platforma. System automatycznie
     wylicza cenę końcową dla każdego marketplace.

  5. SYNCHRONIZACJA STATUSÓW
     Po publikacji system sprawdza czy ogłoszenie jest aktywne,
     wygasło lub zostało odrzucone. Jeden klik "Synchronizuj".

  6. PODGLĄD OGŁOSZENIA
     Przed publikacją widzisz jak ogłoszenie będzie wyglądać:
     zdjęcia, tytuł, cena, opis — w szacie zbliżonej do Allegro.

  7. PANEL PLATFORM
     OAuth połączenie z Allegro i OLX (popup). Otomoto przez
     login biznesowy. Status połączenia każdej platformy widoczny.

  ─────────────────────────────────────────────
  ISTNIEJĄCE EKRANY APLIKACJI (do redesign/inspiracji)
  ─────────────────────────────────────────────
  Panel ma 6 zakładek w lewym sidebarze:
  - Dashboard — statystyki (aktywne ogłoszenia, platformy)
  - Ogłoszenia — lista z filtrem statusu, kolumny: zdjęcie,
    tytuł, stan, cena, status, platformy, akcje
  - Nowe ogłoszenie — 4-5 krokowy wizard:
    Krok 1: wybór kategorii (kafle z ikonami)
    Krok 2: dla motoryzacji: marka/model pojazdu + VIN;
            dla innych: marka + model + atrybuty (kolor, rozmiar)
    Krok 3: zdjęcia (drag&drop)
    Krok 4: cena, platformy do publikacji
  - Zamówienia — tabela zamówień (placeholder, w budowie)
  - Platformy — karty platform z OAuth connect
  - Ustawienia — marże, konto

  ─────────────────────────────────────────────
  STACK (dla kontekstu technicznego)
  ─────────────────────────────────────────────
  Frontend: React 18, TypeScript, Vite, Tailwind CSS, shadcn/ui
  Backend: Node.js, Express, PostgreSQL, Prisma, BullMQ
  AI: Anthropic Claude (haiku) do generowania opisów

  ─────────────────────────────────────────────
  KIERUNEK DESIGNU
  ─────────────────────────────────────────────
  Styl: nowoczesny SaaS B2B — jak Shopify, BaseLinker, Sellasist
  Ton: profesjonalny ale dostępny, nie korporacyjny
  Kolory: do zaproponowania — coś między granatowym/teal
    a pomarańczowym (ala Allegro ale odróżnialne)
  Typografia: czytelna, bezszeryfowa (Inter, Geist, DM Sans)
  Brak: flashowych animacji, ciemnych tła na landingu,
    stockowych zdjęć uśmiechniętych ludzi

  Referencje stylu UI:
  - Linear.app (czystość, spacing)
  - Vercel dashboard (kontrast, komponenty)
  - Allegro Seller Center (kontekst branżowy)

  ─────────────────────────────────────────────
  SEKCJE LANDING PAGE (w kolejności)
  ─────────────────────────────────────────────
  1. HERO
     Headline + subheadline + CTA "Wypróbuj za darmo"
     Mockup/screenshot panelu aplikacji (dashboard lub wizard)
     Social proof: "Zaufali nam X sprzedawców" (placeholder)

  2. PROBLEM (3 karty)
     "Ręczne wystawianie na 4 platformy = 4x więcej pracy"
     "Każda platforma wymaga innego formatu opisu i tytułu"
     "Nie wiesz które ogłoszenia są aktywne, a które wygasły"

  3. ROZWIĄZANIE — jak to działa (3 kroki)
     Krok 1: Stwórz ogłoszenie raz
     Krok 2: AI generuje opisy i tytuły per platforma
     Krok 3: Publikuj jednym kliknięciem, synchronizuj statusy

  4. FUNKCJE (grid 6 kafelków z ikonami)
     AI Opisy | Multichannel | Zarządzanie kategoriami
     Marże | Synchronizacja | Podgląd ogłoszenia

  5. DEMO / SCREENSHOT
     Duży mockup wizarda ogłoszenia lub listy ogłoszeń
     z widocznymi chipami platform (ALLEGRO zielony, OLX limonkowy)

  6. INTEGRACJE
     Loga platform: Allegro, OLX, Otomoto, Ovoko
     "Wkrótce: eBay, Amazon" (planned)

  7. CENNIK (placeholder)
     FREE: X ogłoszeń/mies.
     PRO: nieograniczone + AI
     BUSINESS: multi-user + API

  8. CTA końcowe
     "Zacznij sprzedawać mądrzej"
     Przycisk rejestracji

  9. FOOTER
     Linki: O nas, Kontakt, Regulamin, Privacy Policy
     Social: LinkedIn, Facebook

  ─────────────────────────────────────────────
  DODATKOWE WYTYCZNE
  ─────────────────────────────────────────────
  - Responsive: mobile-first, ale główna grupa używa desktop
  - Accessibility: kontrast WCAG AA
  - Język: polski (landing PL, nie EN)
  - Logo: do zaprojektowania — może nawiązywać do "S"
    lub multichannel (kilka strzałek/połączeń)
  - Nazwa do potwierdzenia: "Seltry" / "AutoLister" / inna

  Dostarcz:
  1. Landing page (full scroll)
  2. Propozycję palety kolorów + typografii
  3. Komponenty UI aplikacji (sidebar, karty platform,
     wizard steps, tabela ogłoszeń) w spójnym stylu
  4. Logo 2-3 warianty
</pasted_text>

<!-- The user explicitly selected the following skills for this project, as attachments to their message. These are not optional context — they define how you work. Use them. -->
<attached-skill name="Hi-fi design">
Create a high-fidelity, polished design. Follow the instructions about design in your system prompt, particularly the 'How to do design work' section. Use the design_canvas starter component, or make a full-bleed prototype and offer options via Tweaks.
</attached-skill>

<attached-skill name="Interactive prototype">
Create a fully interactive prototype with realistic state management and transitions. Use React useState/useEffect for dynamic behavior. Include hover states, click interactions, form validation, animated transitions, and multi-step navigation flows. It should feel like a real working app, not a static mockup.
</attached-skill>


<system-reminder>Auto-injected reminder (ignore if not relevant): do not recreate copyrighted or branded UI unless the user's email domain matches that company. Create original designs instead.</system-reminder>

## Assistant

_[tool: questions_v2]_

## User

Questions answered:
- name: Selltry
- scope: Wszystko naraz
- presentation: Jeden długi landing + osobne pliki ekranów aplikacji
- type: DM Sans (przyjazne)
- logo_direction: Monogram 'S' z motywem multichannel (strzałki/węzły)
- tone: Konkretny i biznesowy (BaseLinker-like)
- hero_visual: Mockup dashboardu
- variations: Jedna wersja, dopracowana
- interactivity: Pełny prototyp: wizard działa krok po kroku, formularz waliduje, AI 'generuje' opis
- social_proof: Statystyki użycia (X ogłoszeń, Y oszczędzonych godzin)

## Assistant

_[tool: update_todos]_

_[tool: write_file]_

_[tool: write_file]_

Committing to the system now:

**Selltry design DNA**
- **Type**: DM Sans (UI/body), DM Mono (prices, IDs, badges)
- **Background**: warm cream `#F6F3EA` (not flat white — feels more product, less generic SaaS)
- **Ink**: `#0E1B2C` 
- **Primary navy**: `#163D6E`
- **CTA orange**: `#FF6A1A` (distinct from Allegro red-orange `#FF5A00`)
- **Accent teal**: `#0E7C66` (success/status)
- **Platform marks**: Allegro coral, OLX lime, Otomoto red, Ovoko blue — colored chips only, no logo recreation
- **Logo**: S-monogram formed by 4 converging arrows (multichannel = 4 platforms → 1 hub)
- **Density**: Linear/Vercel-like — generous whitespace, fine 1px borders, no heavy shadows
- **No gradients, no emoji, no AI-slop iconography** — line icons only, drawn minimally

_[tool: write_file]_

_[tool: write_file]_

_[tool: write_file]_

Now app shell + screens. Building shared CSS first.

_[tool: write_file]_

_[tool: write_file]_

_[tool: write_file]_

Now the interactive wizard — the showcase piece. I'll split it into a JSX component file for size manageability.Now the wizard host HTML page with styles:

_[tool: write_file]_

_[tool: show_html]_

_[tool: write_file]_

Continuing with platforms, orders, settings, and design system page.

_[tool: write_file]_

_[tool: write_file]_

_[tool: write_file]_

_[tool: update_todos]_

_[tool: done]_

_[tool: fork_verifier_agent]_

Gotowe — Selltry w komplecie.

**Co dostarczyłem:**
- **`index.html`** — landing PL (9 sekcji: hero z dashboard mockup, problem, jak działa, 6 funkcji, demo wizarda, integracje, cennik, CTA, footer)
- **App** (6 ekranów, spójny sidebar): `app/dashboard.html`, `app/listings.html`, `app/new-listing.html` (interaktywny wizard 4-kroki z AI gen + publish flow), `app/platforms.html`, `app/orders.html`, `app/settings.html`
- **`design-system.html`** — 5 wariantów logo, paleta, typografia, komponenty
- **Logo** — monogram „S" zbudowany z dwóch przeciwbieżnych strzałek (metafora multichannel)

**System DNA:** DM Sans + DM Mono · cream `#F6F3EA` / navy `#163D6E` / orange `#FF6A1A` / teal accent · własne, oryginalne chipy platform (coral/lime/red/blue) — nie odtworzenia brand assets Allegro/OLX/Otomoto/Ovoko.

**Wizard działa interaktywnie:** wybór kategorii → marka (chipy) + model/VIN/atrybuty → AI „streamuje" tytuły dopasowane do limitów każdej platformy (75/70/65/80 zn.) + opis → drag&drop zdjęć → marże per platforma + checkboxy publikacji → animowany overlay publikacji. Walidacja na każdym kroku.

Weryfikator robi obchód w tle.

