// Selltry — New Listing Wizard
// 4-step interactive flow with validation, AI mock generation, and platform publish.

const { useState, useEffect, useRef, useMemo } = React;

// ============================================================
// DATA
// ============================================================

const CATEGORIES = [
  { id: 'moto', name: 'Motoryzacja', sub: 'Części, opony, akcesoria', popular: true,
    icon: <path d="M3 14h22M5 14V8l3-3h12l3 3v6M7 14v3a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-3M17 14v3a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-3M9 11h10" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round"/> },
  { id: 'elek', name: 'Elektronika', sub: 'Telefony, laptopy, audio',
    icon: <><rect x="4" y="4" width="20" height="14" rx="2" stroke="currentColor" strokeWidth="1.5" fill="none"/><path d="M2 22h24" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></> },
  { id: 'dom', name: 'Dom i ogród', sub: 'Meble, AGD, dekoracje',
    icon: <path d="M4 14L14 5l10 9M6 12v10h6v-6h4v6h6V12" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinejoin="round"/> },
  { id: 'moda', name: 'Moda', sub: 'Ubrania, buty, akcesoria',
    icon: <path d="M9 4l5 3 5-3 4 4-4 4v10H10V12L6 8z" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinejoin="round"/> },
  { id: 'sport', name: 'Sport', sub: 'Wyposażenie, odzież sport.',
    icon: <><circle cx="14" cy="14" r="9" stroke="currentColor" strokeWidth="1.5" fill="none"/><path d="M5 14h18M14 5v18M7 7l14 14M21 7L7 21" stroke="currentColor" strokeWidth="1.5"/></> },
  { id: 'narz', name: 'Narzędzia', sub: 'Elektronarzędzia, ręczne', popular: true,
    icon: <path d="M19 4l5 5-3 3-3-3-7 7 2 2-7 7-3-3 7-7 2 2 7-7-3-3z" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinejoin="round"/> },
  { id: 'inne', name: 'Inne', sub: 'Kolekcje, książki, hobby',
    icon: <><circle cx="14" cy="14" r="2" fill="currentColor"/><circle cx="6" cy="14" r="2" fill="currentColor"/><circle cx="22" cy="14" r="2" fill="currentColor"/></> },
];

const BRANDS = {
  moto: ['BMW', 'Audi', 'Volkswagen', 'Mercedes', 'Toyota', 'Ford', 'Bosch', 'Continental', 'Mann', 'Brembo', 'Sachs', 'Hella'],
  elek: ['Samsung', 'Apple', 'Xiaomi', 'Sony', 'LG', 'Lenovo', 'Asus', 'Dell', 'HP', 'Huawei'],
  dom:  ['IKEA', 'Bosch', 'Philips', 'Karcher', 'Tefal', 'Zelmer', 'Amica', 'Whirlpool'],
  moda: ['Nike', 'Adidas', 'Reebok', 'Puma', 'New Balance', 'Tommy Hilfiger', 'Levis', 'Calvin Klein'],
  sport:['Nike', 'Adidas', 'Reebok', 'Decathlon', 'Wilson', 'Head', 'Speedo'],
  narz: ['Bosch', 'Makita', 'DeWalt', 'Milwaukee', 'Stanley', 'Hilti', 'Festool', 'Einhell'],
  inne: ['Lego', 'Disney', 'Warner', 'inne'],
};

const PLATFORMS = [
  { id: 'a', name: 'Allegro',  bg: 'var(--pf-allegro-bg)', fg: 'var(--pf-allegro)', titleLimit: 75, descLimit: 12000 },
  { id: 'o', name: 'OLX',      bg: 'var(--pf-olx-bg)',     fg: 'var(--pf-olx)',     titleLimit: 70, descLimit: 9000 },
  { id: 'm', name: 'Otomoto',  bg: 'var(--pf-otomoto-bg)', fg: 'var(--pf-otomoto)', titleLimit: 65, descLimit: 8000, motoOnly: true },
  { id: 'v', name: 'Ovoko',    bg: 'var(--pf-ovoko-bg)',   fg: 'var(--pf-ovoko)',   titleLimit: 80, descLimit: 6000, motoOnly: true },
];

// ============================================================
// HELPERS
// ============================================================

const fmt = (n) => n.toLocaleString('pl-PL', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// Mock AI generation that "writes" character by character
async function generateAIContent(state, onChunk) {
  const { brand, model, attrs, condition, category } = state;
  const isAuto = category === 'moto';
  const base = brand && model ? `${brand} ${model}` : 'Produkt';

  const baseDesc = isAuto
    ? `${base}\n\nOryginalna część ${brand} w stanie ${condition === 'new' ? 'nowym' : 'używanym, sprawdzonym technicznie'}. Pasuje do modelu ${model}${attrs.year ? ` (rocznik ${attrs.year})` : ''}.\n\n• Producent: ${brand}\n• Numer katalogowy: ${attrs.partNo || 'OEM'}\n• Stan: ${condition === 'new' ? 'Nowa, oryginalnie pakowana' : 'Używana, sprawna, gotowa do montażu'}\n${attrs.vin ? `• VIN sprawdzony: ${attrs.vin}` : ''}\n\nWysyłka: 24h od zaksięgowania wpłaty. Faktura VAT na życzenie. Gwarancja zwrotu 14 dni.`
    : `${base}\n\n${brand} ${model} w stanie ${condition === 'new' ? 'nowym' : 'używanym'}${attrs.color ? `, kolor: ${attrs.color}` : ''}${attrs.size ? `, rozmiar: ${attrs.size}` : ''}.\n\n• Marka: ${brand}\n• Model: ${model}\n• Stan: ${condition === 'new' ? 'Nowy, oryginalnie pakowany' : 'Używany'}\n${attrs.color ? `• Kolor: ${attrs.color}\n` : ''}${attrs.size ? `• Rozmiar: ${attrs.size}\n` : ''}\nWysyłka kurierem 24h. Faktura na życzenie. Zwrot 14 dni bez podawania przyczyny.`;

  const titleVariants = {
    a: `${brand} ${model}${attrs.color ? ' ' + attrs.color : ''}${attrs.size ? ' rozm. ' + attrs.size : ''}${condition === 'new' ? ' NOWY' : ' używany'}${isAuto && attrs.partNo ? ' ' + attrs.partNo : ''}`.slice(0, 75),
    o: `${brand} ${model}${attrs.year ? ' ' + attrs.year : ''}${attrs.color ? ' ' + attrs.color : ''} ${condition === 'new' ? 'nowy' : 'używany'}`.slice(0, 70),
    m: isAuto ? `${brand} ${model}${attrs.year ? ' ' + attrs.year : ''} — ${attrs.partNo || 'część'}`.slice(0, 65) : '',
    v: isAuto ? `${brand} ${model}${attrs.partNo ? ' ' + attrs.partNo : ''} ${condition === 'new' ? 'NEW' : 'USED'}`.slice(0, 80) : '',
  };

  // Stream
  for (const platform of ['a','o','m','v']) {
    if (!titleVariants[platform]) continue;
    for (let i = 1; i <= titleVariants[platform].length; i += 2) {
      onChunk({ titles: { [platform]: titleVariants[platform].slice(0, i) } });
      await new Promise(r => setTimeout(r, 12));
    }
    onChunk({ titles: { [platform]: titleVariants[platform] } });
  }
  for (let i = 1; i <= baseDesc.length; i += 8) {
    onChunk({ description: baseDesc.slice(0, i) });
    await new Promise(r => setTimeout(r, 8));
  }
  onChunk({ description: baseDesc });
}

// ============================================================
// SHARED MICRO-COMPONENTS
// ============================================================

function StepperBar({ step, max, onJump }) {
  const labels = ['Kategoria', 'Atrybuty', 'Zdjęcia', 'Cena i platformy'];
  return (
    <div className="stepper">
      {labels.map((l, i) => (
        <div key={i} className={`stp ${i < step ? 'done' : ''} ${i === step ? 'cur' : ''}`} onClick={() => i <= step && onJump(i)}>
          <span className="stp-num">{i < step ? <svg width="11" height="11" viewBox="0 0 11 11"><path d="M2 5.5l2.2 2.2 5-5" stroke="currentColor" strokeWidth="1.8" fill="none" strokeLinecap="round"/></svg> : (i+1).toString().padStart(2,'0')}</span>
          <span className="stp-label">{l}</span>
          {i < 3 && <span className="stp-line" />}
        </div>
      ))}
    </div>
  );
}

function PfChip({ id, sm }) {
  const p = PLATFORMS.find(x => x.id === id);
  return <span className={`pf-chip pf-${p.name.toLowerCase()}`} style={sm ? {height:20,padding:'0 7px',fontSize:10} : {}}><span className="pf-mark" /></span>;
}

function CharCount({ current, max }) {
  const ratio = current / max;
  const cls = ratio > 1 ? 'over' : ratio > 0.9 ? 'near' : '';
  return <span className={`char-count ${cls}`}>{current}/{max}</span>;
}

// ============================================================
// STEP 1 — CATEGORY
// ============================================================

function Step1Category({ state, set }) {
  return (
    <div className="step-pane">
      <div className="step-head">
        <span className="t-eyebrow">Krok 1 z 4</span>
        <h2>Wybierz kategorię</h2>
        <p>Wpłynie to na zestaw atrybutów i platformy, na które możesz publikować.</p>
      </div>
      <div className="cat-grid">
        {CATEGORIES.map(c => (
          <button key={c.id}
            className={`cat-tile ${state.category === c.id ? 'sel' : ''}`}
            onClick={() => set({ category: c.id, brand: '', model: '', attrs: {} })}>
            {c.popular && <span className="cat-pop">popularne</span>}
            <svg className="cat-ic" viewBox="0 0 28 28" fill="none">{c.icon}</svg>
            <div>
              <div className="cat-name">{c.name}</div>
              <div className="cat-sub">{c.sub}</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// STEP 2 — ATTRIBUTES
// ============================================================

function Step2Attributes({ state, set, errors }) {
  const isAuto = state.category === 'moto';
  const isModa = state.category === 'moda';
  const brandList = BRANDS[state.category] || [];

  return (
    <div className="step-pane">
      <div className="step-head">
        <span className="t-eyebrow">Krok 2 z 4</span>
        <h2>{isAuto ? 'Dane pojazdu i części' : 'Marka i atrybuty'}</h2>
        <p>Im dokładniej, tym lepszy opis wygeneruje AI.</p>
      </div>

      <div className="form-grid">
        <div className="field">
          <div className="label-row"><label>Marka *</label><span className="hint">{brandList.length} marek</span></div>
          <div className="brand-chips">
            {brandList.map(b => (
              <button key={b} type="button" className={`brand-chip ${state.brand === b ? 'on' : ''}`} onClick={() => set({ brand: b })}>{b}</button>
            ))}
          </div>
          {errors.brand && <div className="field-error">{errors.brand}</div>}
        </div>

        <div className="field">
          <div className="label-row"><label>Model *</label></div>
          <input className={`input ${errors.model ? 'error' : ''}`} placeholder={isAuto ? 'np. BMW E46 318i' : 'np. Tech Fleece XL'} value={state.model} onChange={e => set({ model: e.target.value })}/>
          {errors.model && <div className="field-error">{errors.model}</div>}
        </div>

        <div className="field">
          <div className="label-row"><label>Stan *</label></div>
          <div className="seg-radio">
            <button type="button" className={state.condition === 'new' ? 'on' : ''} onClick={() => set({ condition: 'new' })}>Nowy</button>
            <button type="button" className={state.condition === 'used' ? 'on' : ''} onClick={() => set({ condition: 'used' })}>Używany</button>
            <button type="button" className={state.condition === 'refurb' ? 'on' : ''} onClick={() => set({ condition: 'refurb' })}>Powystawowy</button>
          </div>
        </div>

        {isAuto ? (
          <>
            <div className="field">
              <div className="label-row"><label>Numer katalogowy / OEM</label></div>
              <input className="input t-mono" placeholder="np. 0001125045" value={state.attrs.partNo || ''} onChange={e => set({ attrs: { ...state.attrs, partNo: e.target.value } })}/>
            </div>
            <div className="field">
              <div className="label-row"><label>Rocznik</label></div>
              <input className="input" placeholder="np. 2005" value={state.attrs.year || ''} onChange={e => set({ attrs: { ...state.attrs, year: e.target.value } })}/>
            </div>
            <div className="field span-2">
              <div className="label-row"><label>VIN pojazdu (opcjonalny)</label><span className="hint">17 znaków · sprawdzenie kompatybilności</span></div>
              <input className={`input t-mono ${errors.vin ? 'error' : ''}`} placeholder="WBAEU31040PN12345" maxLength={17} value={state.attrs.vin || ''} onChange={e => set({ attrs: { ...state.attrs, vin: e.target.value.toUpperCase() } })}/>
              {errors.vin && <div className="field-error">{errors.vin}</div>}
            </div>
          </>
        ) : (
          <>
            <div className="field">
              <div className="label-row"><label>{isModa ? 'Rozmiar' : 'Rozmiar / wymiary'}</label></div>
              <input className="input" placeholder={isModa ? 'np. XL, 42, M/L' : 'np. 30×40 cm'} value={state.attrs.size || ''} onChange={e => set({ attrs: { ...state.attrs, size: e.target.value } })}/>
            </div>
            <div className="field">
              <div className="label-row"><label>Kolor</label></div>
              <input className="input" placeholder="np. czarny, granatowy" value={state.attrs.color || ''} onChange={e => set({ attrs: { ...state.attrs, color: e.target.value } })}/>
            </div>
          </>
        )}
      </div>

      {/* AI generator */}
      <AISection state={state} set={set} />
    </div>
  );
}

// ============================================================
// AI GENERATOR SECTION
// ============================================================

function AISection({ state, set }) {
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState('');
  const canGen = state.brand && state.model;

  async function run() {
    if (!canGen) { setError('Wpisz markę i model żeby AI miało z czego generować.'); return; }
    setError('');
    setGenerating(true);
    set({ titles: { a: '', o: '', m: '', v: '' }, description: '' });
    await generateAIContent(state, (chunk) => {
      set(prev => ({
        titles: chunk.titles ? { ...prev.titles, ...chunk.titles } : prev.titles,
        description: chunk.description !== undefined ? chunk.description : prev.description,
      }));
    });
    setGenerating(false);
  }

  return (
    <div className="ai-section">
      <div className="ai-section-head">
        <div className="ai-badge">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M7 1.5l1.5 4 4 1.5-4 1.5L7 12.5l-1.5-4-4-1.5 4-1.5z" strokeLinejoin="round"/></svg>
          <span>AI Generator</span>
        </div>
        <div className="ai-info">Claude haiku · ~2s · dopasowane do <b>{CATEGORIES.find(c => c.id === state.category)?.name}</b></div>
        <button type="button" className={`btn btn-sm ${generating ? 'btn-secondary' : 'btn-primary'}`} onClick={run} disabled={generating}>
          {generating ? <><span className="spinner"/>Generuję…</> : (state.description ? 'Wygeneruj ponownie' : 'Wygeneruj opisy i tytuły')}
        </button>
      </div>
      {error && <div className="ai-error">{error}</div>}

      {/* Titles per platform */}
      <div className="titles-grid">
        {PLATFORMS.filter(p => !p.motoOnly || state.category === 'moto').map(p => (
          <div key={p.id} className="title-card">
            <div className="title-card-h">
              <PfChip id={p.id} />
              <CharCount current={(state.titles[p.id] || '').length} max={p.titleLimit} />
            </div>
            <input
              className="input title-input"
              placeholder={generating ? '' : 'Wciśnij Generuj lub wpisz ręcznie'}
              value={state.titles[p.id] || ''}
              onChange={e => set(prev => ({ titles: { ...prev.titles, [p.id]: e.target.value } }))}
              maxLength={p.titleLimit}
            />
          </div>
        ))}
      </div>

      {/* Description */}
      <div className="field" style={{marginTop:16}}>
        <div className="label-row">
          <label>Opis ogłoszenia</label>
          <span className="hint">{(state.description || '').length} znaków · używany na wszystkich platformach</span>
        </div>
        <textarea className="textarea" rows={10} placeholder={generating ? 'AI pisze opis…' : 'Pełny opis marketingowy — specyfikacja, kompatybilność, wysyłka.'} value={state.description} onChange={e => set({ description: e.target.value })}/>
      </div>
    </div>
  );
}

// ============================================================
// STEP 3 — PHOTOS
// ============================================================

function Step3Photos({ state, set, errors }) {
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef();

  const onFiles = (files) => {
    const arr = Array.from(files).slice(0, 12 - state.photos.length).map((f, i) => ({
      id: Date.now() + i,
      name: f.name,
      size: f.size,
    }));
    set({ photos: [...state.photos, ...arr] });
  };

  // Mock-add buttons (without real files)
  const addMock = () => {
    const next = Array.from({length: 4}, (_, i) => ({
      id: Date.now() + i,
      name: `IMG_${(state.photos.length + i + 1).toString().padStart(4,'0')}.jpg`,
      size: 1_240_000 + Math.random() * 2_000_000,
    }));
    set({ photos: [...state.photos, ...next].slice(0, 12) });
  };

  return (
    <div className="step-pane">
      <div className="step-head">
        <span className="t-eyebrow">Krok 3 z 4</span>
        <h2>Zdjęcia produktu</h2>
        <p>Min. 1, maks. 12 zdjęć. Pierwsze będzie miniaturą na wszystkich platformach.</p>
      </div>

      <div className={`dropzone ${dragOver ? 'over' : ''} ${errors.photos ? 'error' : ''}`}
        onDragOver={e => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={e => { e.preventDefault(); setDragOver(false); onFiles(e.dataTransfer.files); }}
        onClick={() => inputRef.current.click()}>
        <input type="file" accept="image/*" multiple ref={inputRef} hidden onChange={e => onFiles(e.target.files)}/>
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5">
          <rect x="3" y="6" width="26" height="20" rx="2"/>
          <circle cx="11" cy="13" r="2"/>
          <path d="M3 22l8-7 6 5 4-3 8 6" strokeLinejoin="round"/>
        </svg>
        <div className="dz-title">Przeciągnij zdjęcia lub <span className="lk">wybierz pliki</span></div>
        <div className="dz-sub">JPG / PNG / WEBP do 8MB · maks. 12 zdjęć</div>
        <div style={{marginTop:14}}>
          <button type="button" className="btn btn-sm btn-secondary" onClick={(e) => { e.stopPropagation(); addMock(); }}>+ Dodaj 4 przykładowe zdjęcia</button>
        </div>
      </div>
      {errors.photos && <div className="field-error" style={{marginTop:8}}>{errors.photos}</div>}

      {state.photos.length > 0 && (
        <div className="photo-grid">
          {state.photos.map((p, i) => (
            <div key={p.id} className="photo-tile">
              <div className="photo-img thumb-img">
                {i === 0 && <span className="photo-cover">Miniatura</span>}
                <span className="photo-idx">{i + 1}</span>
              </div>
              <div className="photo-meta">
                <span className="photo-name">{p.name}</span>
                <button type="button" className="photo-rm" onClick={() => set({ photos: state.photos.filter(x => x.id !== p.id) })}>
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M3 3l6 6M9 3l-6 6"/></svg>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================================
// STEP 4 — PRICING + PLATFORMS
// ============================================================

function Step4Pricing({ state, set, errors }) {
  const isAuto = state.category === 'moto';
  const availablePlatforms = PLATFORMS.filter(p => !p.motoOnly || isAuto);
  const margins = state.margins;

  const finalPrice = (pf) => {
    if (!state.price) return 0;
    const m = margins[pf];
    if (m.type === 'pct') return state.price * (1 + m.value / 100);
    return state.price + m.value;
  };

  const togglePf = (pf) => {
    const next = state.publishOn.includes(pf) ? state.publishOn.filter(x => x !== pf) : [...state.publishOn, pf];
    set({ publishOn: next });
  };

  return (
    <div className="step-pane">
      <div className="step-head">
        <span className="t-eyebrow">Krok 4 z 4</span>
        <h2>Cena, marże i publikacja</h2>
        <p>Ustaw cenę bazową — marże doliczy się automatycznie pod każdą platformę.</p>
      </div>

      <div className="pricing-grid">
        <div>
          <div className="field">
            <div className="label-row"><label>Cena bazowa *</label><span className="hint">netto, brutto przeliczy się po publikacji</span></div>
            <div className="input-suffix">
              <input className={`input t-mono ${errors.price ? 'error' : ''}`} type="number" placeholder="0,00" value={state.price || ''} onChange={e => set({ price: parseFloat(e.target.value) || 0 })}/>
              <span className="suffix">zł</span>
            </div>
            {errors.price && <div className="field-error">{errors.price}</div>}
          </div>

          <div className="field">
            <div className="label-row"><label>Marże per platforma</label></div>
            <div className="margins-list">
              {availablePlatforms.map(p => (
                <div key={p.id} className="margin-row">
                  <PfChip id={p.id} />
                  <span className="margin-name">{p.name}</span>
                  <div className="seg-radio mini">
                    <button type="button" className={margins[p.id].type === 'pct' ? 'on' : ''} onClick={() => set({ margins: { ...margins, [p.id]: { ...margins[p.id], type: 'pct' } } })}>%</button>
                    <button type="button" className={margins[p.id].type === 'fix' ? 'on' : ''} onClick={() => set({ margins: { ...margins, [p.id]: { ...margins[p.id], type: 'fix' } } })}>zł</button>
                  </div>
                  <input className="input mini t-mono" type="number" value={margins[p.id].value} onChange={e => set({ margins: { ...margins, [p.id]: { ...margins[p.id], value: parseFloat(e.target.value) || 0 } } })}/>
                  <span className="margin-final t-mono">{fmt(finalPrice(p.id))} zł</span>
                </div>
              ))}
            </div>
          </div>

          <div className="field">
            <div className="label-row"><label>Publikuj na platformach *</label><span className="hint">{state.publishOn.length} z {availablePlatforms.length} wybranych</span></div>
            <div className="pubs">
              {availablePlatforms.map(p => {
                const on = state.publishOn.includes(p.id);
                return (
                  <label key={p.id} className={`pub-row ${on ? 'on' : ''}`} onClick={() => togglePf(p.id)}>
                    <span className={`cbx ${on ? 'checked' : ''}`}><svg width="10" height="10" viewBox="0 0 10 10"><path d="M2 5l2 2 4-4" stroke="#fff" strokeWidth="2" fill="none" strokeLinecap="round"/></svg></span>
                    <PfChip id={p.id} />
                    <span className="pub-name">{p.name}</span>
                    <span className="pub-price t-mono">{state.price ? fmt(finalPrice(p.id)) + ' zł' : '—'}</span>
                  </label>
                );
              })}
            </div>
            {errors.publishOn && <div className="field-error">{errors.publishOn}</div>}
          </div>
        </div>

        {/* Summary panel */}
        <aside className="summary-panel">
          <div className="sp-head">
            <span className="t-eyebrow" style={{fontSize:11}}>Podsumowanie</span>
            <h3>Twoje ogłoszenie</h3>
          </div>
          <div className="sp-row"><span>Kategoria</span><b>{CATEGORIES.find(c => c.id === state.category)?.name || '—'}</b></div>
          <div className="sp-row"><span>Marka · Model</span><b>{state.brand || '—'} {state.model && '· ' + state.model}</b></div>
          <div className="sp-row"><span>Stan</span><b>{state.condition === 'new' ? 'Nowy' : state.condition === 'used' ? 'Używany' : 'Powystawowy'}</b></div>
          <div className="sp-row"><span>Zdjęcia</span><b>{state.photos.length}</b></div>
          <div className="sp-row"><span>Opis</span><b>{(state.description || '').length} znaków</b></div>
          <div className="sp-divider"/>
          <div className="sp-row big"><span>Cena bazowa</span><b className="t-mono">{state.price ? fmt(state.price) + ' zł' : '—'}</b></div>
          <div className="sp-row"><span>Publikacja na</span><b>{state.publishOn.length} platformach</b></div>
          <div className="sp-platforms">
            {state.publishOn.map(pf => <PfChip key={pf} id={pf} sm />)}
            {state.publishOn.length === 0 && <span style={{color:'var(--muted)',fontSize:12}}>żadnej</span>}
          </div>
        </aside>
      </div>
    </div>
  );
}

// ============================================================
// PUBLISH OVERLAY
// ============================================================

function PublishingOverlay({ state, onClose }) {
  const platforms = state.publishOn.map(id => PLATFORMS.find(p => p.id === id));
  const [progress, setProgress] = useState(platforms.map(() => 'queued'));

  useEffect(() => {
    let timeouts = [];
    platforms.forEach((p, i) => {
      timeouts.push(setTimeout(() => {
        setProgress(prev => { const next = [...prev]; next[i] = 'sending'; return next; });
      }, 400 + i * 800));
      timeouts.push(setTimeout(() => {
        setProgress(prev => { const next = [...prev]; next[i] = 'done'; return next; });
      }, 400 + i * 800 + 1400));
    });
    return () => timeouts.forEach(clearTimeout);
  }, []);

  const allDone = progress.every(s => s === 'done');

  return (
    <div className="pub-overlay">
      <div className="pub-modal">
        <div className="pub-head">
          {allDone
            ? <><div className="pub-ok"><svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 14l5 5 11-11" strokeLinecap="round" strokeLinejoin="round"/></svg></div><h3>Opublikowano</h3><p>Twoje ogłoszenie jest aktywne na {platforms.length} platformach.</p></>
            : <><div className="pub-spin"><div className="spinner big"/></div><h3>Publikuję ogłoszenie…</h3><p>Rozsyłam do {platforms.length} platform równolegle. To zajmie ~10 sekund.</p></>
          }
        </div>
        <div className="pub-list">
          {platforms.map((p, i) => (
            <div key={p.id} className={`pub-step ${progress[i]}`}>
              <PfChip id={p.id} />
              <span className="pub-pname">{p.name}</span>
              <span className="pub-state">
                {progress[i] === 'queued' && 'w kolejce…'}
                {progress[i] === 'sending' && <><span className="spinner small"/> wysyłam…</>}
                {progress[i] === 'done' && <><svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2"><path d="M2 6l3 3 5-5" strokeLinecap="round" strokeLinejoin="round"/></svg> opublikowano</>}
              </span>
            </div>
          ))}
        </div>
        {allDone && (
          <div className="pub-foot">
            <a className="btn btn-secondary" href="listings.html">Wszystkie ogłoszenia</a>
            <button className="btn btn-cta" onClick={onClose}>Wystaw kolejne →</button>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================
// MAIN WIZARD
// ============================================================

function Wizard() {
  const initial = {
    step: 0,
    category: '',
    brand: '',
    model: '',
    condition: 'used',
    attrs: {},
    photos: [],
    titles: { a: '', o: '', m: '', v: '' },
    description: '',
    price: 0,
    margins: { a: { type: 'pct', value: 20 }, o: { type: 'pct', value: 15 }, m: { type: 'pct', value: 6 }, v: { type: 'pct', value: -5 } },
    publishOn: [],
    errors: {},
    publishing: false,
  };
  const [state, _setState] = useState(initial);
  const setState = (patch) => _setState(prev => typeof patch === 'function' ? { ...prev, ...patch(prev) } : { ...prev, ...patch });

  const validate = (step) => {
    const errors = {};
    if (step === 0 && !state.category) errors.category = 'Wybierz kategorię.';
    if (step === 1) {
      if (!state.brand) errors.brand = 'Wybierz markę.';
      if (!state.model.trim()) errors.model = 'Podaj model.';
      if (state.attrs.vin && state.attrs.vin.length !== 17) errors.vin = 'VIN musi mieć 17 znaków.';
    }
    if (step === 2 && state.photos.length === 0) errors.photos = 'Dodaj minimum 1 zdjęcie.';
    if (step === 3) {
      if (!state.price || state.price <= 0) errors.price = 'Podaj cenę większą od 0.';
      if (state.publishOn.length === 0) errors.publishOn = 'Wybierz co najmniej jedną platformę.';
    }
    return errors;
  };

  const next = () => {
    const errors = validate(state.step);
    if (Object.keys(errors).length) { setState({ errors }); return; }
    if (state.step === 3) { setState({ publishing: true }); return; }
    setState({ step: state.step + 1, errors: {} });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const prev = () => { setState({ step: Math.max(0, state.step - 1), errors: {} }); window.scrollTo({top:0,behavior:'smooth'}); };
  const jump = (s) => setState({ step: s, errors: {} });

  const stepProps = { state, set: setState, errors: state.errors };

  return (
    <>
      <StepperBar step={state.step} max={4} onJump={jump} />
      <div className="wizard-body">
        {state.step === 0 && <Step1Category {...stepProps} />}
        {state.step === 1 && <Step2Attributes {...stepProps} />}
        {state.step === 2 && <Step3Photos {...stepProps} />}
        {state.step === 3 && <Step4Pricing {...stepProps} />}
      </div>
      <div className="wizard-foot">
        <button className="btn btn-secondary" onClick={prev} disabled={state.step === 0}>← Wstecz</button>
        <span style={{flex:1, fontSize: 13, color: 'var(--muted)', fontFamily:'var(--font-mono)', letterSpacing:'0.04em', textTransform:'uppercase'}}>Krok {state.step + 1} z 4</span>
        <button className="btn btn-cta" onClick={next}>
          {state.step === 3 ? `Opublikuj na ${state.publishOn.length || 0} platformach →` : 'Dalej →'}
        </button>
      </div>
      {state.publishing && <PublishingOverlay state={state} onClose={() => _setState(initial)} />}
    </>
  );
}

Object.assign(window, { Wizard });
